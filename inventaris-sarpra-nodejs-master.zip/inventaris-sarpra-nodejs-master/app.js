require("dotenv").config()
const express = require("express")
const app = express()
const userRouter = require("./config/router")
const bodyParser = require("body-parser")
// const sessionData = require('session-data');

app.use(express.json())
app.use(bodyParser.urlencoded({extended:false}))
app.use("/api/user", userRouter)
// app.use(sessionData())
app.listen(process.env.APP_PORT, () => {
    console.log(`App running on port ` + process.env.APP_PORT);
})