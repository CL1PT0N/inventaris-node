const { verify } = require("jsonwebtoken")
require("dotenv").config()

module.exports = {
    checkTokenUser: (req, res, next) => {
        let token = req.get("authorization")

        if(token == process.env.pass){
            verify(token, `process.env.sOPK_USR`, (err, decoded) => {
                if(err){
                    res.json({
                        success: false,
                        message: "Token not valid"
                    })
                }else{
                    next()
                }
            })
        }else{
            res.json({
                success: false,
                message: "Token missing, unauthorized user"
            })
        }
    },
    checkTokenAdmin: (req, res, next) => {
        let token = req.get("authorization")

        if(token == process.env.pass){
            verify(token, `process.env.sOPK_ADM`, (err, decoded) => {
                if(err){
                    res.json({
                        success: false,
                        message: "Token not valid"
                    })
                }else{
                    next()
                }
            })
        }else{
            res.json({
                success: false,
                message: "Token missing, unauthorized user"
            })
        }
    }
}