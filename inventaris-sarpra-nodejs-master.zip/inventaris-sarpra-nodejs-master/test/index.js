/**
 * pada dasarnya untuk melakukan proses bulk (banyak) insert atau update
 * cukup memperhatikan dua hal.
 * 1. data yang dikirimkan banyak (dalam bentuk array)
 * 2. operasi menggunakan perulangan
 * 
 * berikut contoh proses bulk insert data karyawan dimana kita akan mendapat
 * request dari endpoint berbentuk sebagai berikut
 *      [
 *          {
 *              "name": "Budi Hartanto",
 *              "email": "budi.hartanto@mail.test",
 *              "department": "Teknologi Informasi"
 *          },
 *          {
 *              "name": "Eka Yuliana",
 *              "email": "eka.yuliana@mail.test",
 *              "department": "Marketing"
 *          }
 *      ]
 */

const express = require('express')
const bodyParser = require('body-parser')
const mysql = require('mysql')

const app = express()
const port = 3000

const db = mysql.createConnection({
    host: '127.0.0.1',
    port: '3306',
    user: 'root',
    password: '',
    database: 'node_employee',
})

app.use(bodyParser.json())
app.use(bodyParser.raw())
app.use(bodyParser.urlencoded({
    extended: true
}))

// end point untuk mendapatkan seluruh data karyawan
app.get('/employees', (req, res) => {
    let sql = `
        select * from employees;
    `

    db.query(sql, (err, result) => {
        if (err) throw err

        res.json({
            message: 'success get all employee',
            data: result
        })
    })
})

// end point untuk menambahkan data karyawan
app.post('/employees', (req, res) => {
    // karena kiriman dari endpoint berbentuk array,
    // maka data disini juga berbentuk array
    data = req.body;

    // proses bulk insert dilakukan dengan perulangan
    // pada variabel data
    data.forEach(element => {
        // meng-eksekusi queri untuk insert setiap element dari data karyawan
        db.query(
            `
            insert into employees (name, email, department)
            values ('`+ element.name + `', '` + element.email + `', '` + element.department + `')
        `,
            (err, result) => {
                if (err) throw err
            })
    });
    // setelah proses perulangan berhasil maka mengirim balikan
    res.json({
        message: 'success add employees',
        data
    })

})

app.listen(port, () => {
    console.log('app running on port ' + port)
})