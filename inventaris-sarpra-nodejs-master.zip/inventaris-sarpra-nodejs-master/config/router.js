const {
    controlAddUser,
    controlUpdateUser,
    controlLogIn
} = require("../api/user/user.controller")

const {
    controlDeleteUser,
    controlViewUser
} = require("../api/admin/admin.controller")

const {
    controlViewInv,
    controlAddInv,
    controlLoanInv,
    controlReturnInv,
    controlUpdateInv,
    controlCheckUserLoan
} = require("../api/inventaris/inventaris.controller")

const router = require("express").Router()
const { checkTokenUser, checkTokenAdmin } = require("../auth/token_validation")

router.post("/user", controlAddUser)
router.post("/login", controlLogIn)
router.get("/user", checkTokenAdmin, controlViewUser)
router.patch("/edit", checkTokenUser, controlUpdateUser)
router.delete("/delete/:id", checkTokenAdmin, controlDeleteUser)
router.get("/inv", controlViewInv)
router.post("/inv", checkTokenAdmin, controlAddInv)
router.post("/inv/loan", checkTokenUser, controlLoanInv)
router.get("/inv/loan", checkTokenUser, controlCheckUserLoan)
router.post("/inv/edit", checkTokenAdmin, controlUpdateInv)
router.post("/inv/loan/return", checkTokenUser, controlReturnInv)

module.exports = router