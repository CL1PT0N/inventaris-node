const {
    addUser,
    updateUser,
    logIn
} = require("./user.service")

const {
    genSaltSync,
    hashSync,
    compareSync
} = require("bcrypt")

const { sign } = require("jsonwebtoken")
require("dotenv").config()

module.exports = {
    controlAddUser: (req, res) => {
        const data = req.body
        // const salt = genSaltSync(10)
        // data.password = hashSync(`data.password`, salt)
        addUser(data, (err, result) => {
            if(err){
                console.log(err);
                return res.status(500).json({
                    condition: false,
                    message: "DB error"
                })
            }else{
                return res.status(200).json({
                    condition: true,
                    data: result,
                    message: "User added succesfully"
                })
            }
        })
    },
    controlUpdateUser: (req, res) => {
        const data = req.body
        data.id = process.env.id
        // const salt = genSaltSync(10)
        // data.password = hashSync('yeyes', salt)
        updateUser(data, (err, result) => {
            if(err){
                console.log(err);
                return
            }
            if(!result){
                return res.json({
                    success: false,
                    message: "Update failed"
                })
            }else{
                return res.json({
                    success: true,
                    message: "Updated succesfully",
                    data: result
                })
            }
        })
    },
    controlLogIn: (req, res) => {
        const data = req.body
        logIn(data, (err, result) => {
            if(err){
                console.log(err);
            }
            if(!result){
                return res.json({
                    success: false,
                    message: "Invalid email"
                })
            }
            // passMe = 'yeyes'
            // compares = compareSync(passMe, result.password)
            // console.log(compares, data.password, passMe);
            
            if(data.password == result.password){
                if(data.email == `root`){
                    result.password = undefined
                    const jwt = sign(
                        {result:result},
                        `process.env.sOPK_ADM`,
                        {expiresIn: "1h"}
                    )
                    process.env.id = result.id_user
                    process.env.pass = jwt
                    return res.json({
                        success: true,
                        message: "Login success, using admin",
                        account: result,
                        token: jwt
                    })
                }else{
                    result.password = undefined
                    const jwt = sign(
                        {result:result},
                        `process.env.sOPK_USR`,
                        {expiresIn: "1h"}
                    )
                    process.env.id = result.id_user
                    process.env.pass = jwt
                    return res.json({
                        success: true,
                        message: "Login success, using account",
                        account: result,
                        token: jwt
                    })
                }
            }else{
                return res.json({
                    success: false,
                    message: "Invalid password"
                })
            }
        })
    }
}