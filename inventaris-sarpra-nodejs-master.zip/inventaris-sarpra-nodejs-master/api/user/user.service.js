const db = require("../../config/connection")

module.exports = {
    addUser: (data, callBack) => {
        db.query(
            `INSERT INTO user (username, password, class, email) values (?, ?, ?, ?)`,
            [
                data.username,
                data.password,
                data.class,
                data.email
            ],
            (err, result, fields) => {
                if(err){
                    return callBack(err)
                }else{
                    db.query(
                        `SELECT id_user from user where password = ?`,
                        [data.password],
                        (err, result, fields) => {
                            if(err){
                                return callBack(err)
                            } else {
                                return callBack(null, result)
                            }
                        }
                    )
                }
            }
        )
    },
    updateUser: (data, callBack) => {
        db.query(
            `UPDATE user set username = ?, password = ?, class = ?, email = ? where id_user = ?`,
            [
                data.username,
                data.password,
                data.class,
                data.email,
                data.id
            ],
            (err, result, fields) => {
                if(err){
                    return callBack(err)
                }else{
                    return callBack(null, result)
                }
            }
        )
    },
    logIn: (data, callBack) => {
        db.query(
            `SELECT username, email, password, id_user from user where email = ?`,
            [data.email],
            (err, result, fields) => {
                if(err){
                    return callBack(err)    
                    }else{
                    return callBack(null, result[0])    
                    }
            }
        )
    }
}