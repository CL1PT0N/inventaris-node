const db = require("../../config/connection")

module.exports = {
    addInv: (data, callBack) => {
        db.query(
            `INSERT INTO inventaris (nama_inventaris, deskripsi_inventaris, status_inventaris, stok_inventaris) values (?, ?, ?, ?)`,
            [
                data.name,
                data.desk,
                data.stats,
                data.stok
            ],
            (err, result, fields) => {
                if (err) {
                    return callBack(err)
                } else {
                    return callBack(null, result)
                }
            }
        )
    },
    viewInv: (data, callBack) => {
        db.query(
            `SELECT nama_inventaris, deskripsi_inventaris, status_inventaris, stok_inventaris FROM inventaris`,
            [],
            (err, result, fields) => {
                if(err){
                    return callBack(err)
                }else{
                    return callBack(null, result)
                }
            }
        )
    },
    checkInv: (data, callBack) => {
        db.query(
            'SELECT * FROM inventaris WHERE nama_inventaris = ?',
            [data.name],
            (err, result, fields) => {
                if (err) {
                    return callBack(err)
                } else {
                    return callBack(null, result)
                }
            }
        )
    },
    checkAksi: (data, callBack) => {
        db.query(
            'SELECT * FROM aksi WHERE nama_inventaris = ?',
            [data.name],
            (err, result, fields) => {
                if (err) {
                    return callBack(err)
                } else {
                    return callBack(null, result)
                }
            }
        )
    },
    loanInv: (data, callBack) => {
        db.query(
            `UPDATE inventaris set stok_inventaris = ?, stok_inventaris_dipinjam = ? WHERE id_inventaris = ?; INSERT INTO aksi (id_inventaris, id_user, aksi, kuantitas) value (?, ?, ?, ?)`,
            [
                data.stok,
                data.stok_dipinjam,
                data.id_inventaris,
                data.id_inventaris,
                data.id_user,
                data.aksi,
                data.kuantitas
            ],
            (err, result, fields) => {
                if (err) {
                    return callBack(err)
                } else {
                    return callBack(null, result)
                }
            }
        )
    },
    returnInv: (data, callBack) => {
        db.query(
            `UPDATE inventaris set stok_inventaris = ?, stok_inventaris_dipinjam = ? WHERE id_inventaris = ?; UPDATE aksi set aksi = ? WHERE id_inventaris = ? AND id_user = ?`,
            [
                data.stok_kembali,
                data.stok_kuantitas,
                data.id_inventaris,
                data.aksi,
                data.id_inventaris,
                data.id_user
            ],
            (err, result, fields) => {
                if (err) {
                    return callBack(err)
                } else {
                    return callBack(null, result)
                }
            }
        )
    },
    checkLoan: (data, callBack) => {
        db.query(
            `SELECT * FROM aksi WHERE aksi = ? AND id_user = ? AND id_inventaris = ?`,
            [
                data.aksi_cek,
                data.id_user,
                data.id_inventaris
            ],
            (err, result, fields) => {
                if (err) {
                    return callBack(err)
                } else {
                    return callBack(null, result)
                }
            }
        )
    },
    checkLoanAll: (data, callBack) => {
        db.query(
            `SELECT * FROM aksi WHERE id_user = ?`,
            [
                data.id_user
            ],
            (err, result, fields) => {
                if (err) {
                    return callBack(err)
                } else {
                    return callBack(null, result)
                }
            }
        )
    },
    updateInv: (data, callBack) => {
        db.query(
            `UPDATE inventaris set stok_inventaris = ?, deskripsi_inventaris = ?, status_inventaris = ? WHERE nama_inventaris = ?`,
            [
                data.stok_inventaris,
                data.deskripsi_inventaris,
                data.status_inventaris,
                data.nama_inventaris
            ],
            (err, result, fields) => {
                if (err) {
                    return callBack(err)
                } else {
                    return callBack(null, result)
                }
            }
        )
    }
}