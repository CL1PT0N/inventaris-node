const {
    addInv,
    viewInv,
    checkInv,
    loanInv,
    returnInv, 
    checkLoan,
    updateInv,
    checkLoanAll
} = require("./inventaris.service")

require("dotenv").config()

module.exports = {
    controlViewInv: (req, res) => {
        const data = req.body
        viewInv(data, (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).json({
                    condition: false,
                    message: "DB error"
                })
            } else {
                return res.status(200).json({
                    condition: true,
                    data: result
                })
            }
        })

    },
    controlAddInv: (req, res) => {
        const data_array = req.body
        data_array.forEach(data => {
            addInv(data, (err, result) => {
                if (err) {
                    console.log(err);
                } else {
                    console.log('data ' + data.name + ' berhasil dimasukkan');
                }
            })
        })
        res.json({
            message: "see result on console"
        })
    },
    controlLoanInv: (req, res) => {
        const data = req.body
        checkInv(data, (err, result) => {
            if (!result[0]) {
                return res.status(200).json({
                    message: 'Inventaris tidak ada'
                })
            }
            if (result[0].stok_inventaris <= 0) {
                return res.status(200).json({
                    message: 'Inventaris habis stok'
                })
            } else {
                id_user = process.env.id
                let updated_data = {
                    stok: parseInt(result[0].stok_inventaris) - parseInt(data.kuantitas),
                    stok_dipinjam: parseInt(result[0].stok_inventaris_dipinjam) + parseInt(data.kuantitas),
                    id_user: id_user,
                    id_inventaris: result[0].id_inventaris,
                    aksi: 'Pinjam',
                    kuantitas: data.kuantitas
                }
                console.log(id_user)
                if (data.kuantitas <= 0 || result[0].status_inventaris == 'Hanya beli') {
                    return res.status(200).json({
                        message: '-_-"'
                    })
                } else {
                    loanInv(updated_data, (err, result) => {
                        if (err) {
                            console.log(err)
                            return res.status(500).json({
                                message: 'Peminjaman gagal'
                            })
                        } else {
                            return res.status(200).json({
                                message: 'Peminjaman berhasil',
                                result
                            })
                        }
                    })
                }
            }
        })
    },
    controlReturnInv: (req, res) => {
        const data = req.body
        checkInv(data, (err, result) => {
            if (!result[0]) {
                return res.status(200).json({
                    message: 'Inventaris tidak ada'
                })
            } else {
                id_user = process.env.id
                let updated_data = {
                    stok_kembali: parseInt(result[0].stok_inventaris) + parseInt(data.kuantitas),
                    stok_kuantitas: parseInt(result[0].stok_inventaris_dipinjam) - parseInt(data.kuantitas),
                    aksi: 'Kembali',
                    id_inventaris: result[0].id_inventaris,
                    id_user: parseInt(id_user),
                    aksi_cek: 'Pinjam'
                }
                checkLoan(updated_data, (err, results) => {
                    if(!results[0]){
                        console.log(results)
                        console.log(err)
                        return res.status(500).json({
                            message: 'Gaada obat dah elu'
                        })
                    }
                    if(results[0].kuantitas == data.kuantitas){
                        updated_data.aksi = 'Kembali'
                        returnInv(updated_data, (err, result) => {
                            if (err) {
                                console.log(err)
                                return res.status(500).json({
                                    message: 'Pengembalian gagal'
                                })
                            } else {
                                return res.status(200).json({
                                    message: 'Pengembalian berhasil',
                                    result
                                })
                            }
                        })
                    }else{
                        updated_data.aksi = 'Pinjam'
                        returnInv(updated_data, (err, result) => {
                            if (err) {
                                console.log(err)
                                return res.status(500).json({
                                    message: 'Pengembalian gagal'
                                })
                            } else {
                                return res.status(200).json({
                                    message: 'Pengembalian berhasil',
                                    result
                                })
                            }
                        })
                    }
                })
            }
        })
    },
    controlUpdateInv: (req, res) => {
        const data = req.body
        checkInv(data, (err, result) => {
            if(err){
                console.log(err)
            }
            if(!result[0]){
                return res.status(500).json({
                    message: 'Gaada inventaris'
                })
            }else{
                let datas = {
                    stok_inventaris: parseInt(data.stok) + parseInt(result[0].stok_inventaris),
                    deskripsi_inventaris: data.desk,
                    status_inventaris: data.stats,
                    nama_inventaris: result[0].nama_inventaris
                }
                console.log(result, datas);
                
                updateInv(datas, (err, result) => {
                    if (err) {
                        console.log(err)
                        return res.status(500).json({
                            message: 'Ubah gagal'
                        })
                    } else {
                        return res.status(200).json({
                            message: 'Ubah berhasil',
                            result
                        })
                    }
                })
            }
        })
    },
    controlCheckUserLoan: (req, res) => {
        parameter = {
            id_user: process.env.id,
        }
        checkLoanAll(parameter, (err, result) => {
            if (err) {
                console.log(err)
                return res.status(500).json({
                    message: 'ψ(._. )>'
                })
            } else {
                return res.status(200).json({
                    message: 'Aksi anda',
                    result
                })
            }
        })
    }
}