const {
    deleteUser,
    viewUser
} = require("./admin.service")

// const {
//     genSaltSync,
//     hashSync,
//     compareSync
// } = require("bcrypt")

// const { sign } = require("jsonwebtoken")

module.exports = {
    controlDeleteUser: (req, res) => {
        const id = req.params.id
        deleteUser(id, (err, result) => {
            if(err){
                console.log(err);
                return
            }
            if(!result){
                return res.json({
                    success: false,
                    message: "Delete failed"
                })
            }else{
                return res.json({
                    success: true,
                    message: "Deleted succesfully"
                })
            }
        })
    },
    controlViewUser: (req, res) => {
        viewUser((err, result) => {
            for(i=0;i<result.length;i++){
                result[i].password = undefined
            }
            if(err){
                console.log(err);
                return
            }else{
                return res.json({
                    success: true,
                    data: result
                })
            }
        })
    }
}