const db = require("../../config/connection")

module.exports = {
    deleteUser: (data, callBack) => {
        db.query(
            "DELETE from user where id_user = ?",
            [data],
            (err, result, field) => {
                if(err){
                    return callBack(err)
                }else{
                    return callBack(null, result)
                }
            }
        )
    },
    viewUser: callBack => {
        db.query(
            "SELECT * from user",
            [],
            (err, result, fields) => {
                if(err){
                    return callBack(err)
                }else{
                    return callBack(null, result)
                }
            }
        )
    }
}