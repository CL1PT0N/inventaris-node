-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 06, 2020 at 11:54 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventsarpra`
--

-- --------------------------------------------------------

--
-- Table structure for table `aksi`
--

CREATE TABLE `aksi` (
  `id_aksi` int(11) NOT NULL,
  `id_inventaris` int(255) NOT NULL,
  `id_user` int(255) NOT NULL,
  `jam_aksi` time NOT NULL DEFAULT current_timestamp(),
  `tanggal_aksi` date NOT NULL DEFAULT current_timestamp(),
  `aksi` enum('Beli','Pinjam','Kembali') NOT NULL,
  `kuantitas` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `aksi`
--

INSERT INTO `aksi` (`id_aksi`, `id_inventaris`, `id_user`, `jam_aksi`, `tanggal_aksi`, `aksi`, `kuantitas`) VALUES
(24, 4, 22, '14:42:48', '2020-03-06', 'Kembali', 5),
(25, 4, 22, '05:32:33', '2020-03-07', 'Kembali', 5);

-- --------------------------------------------------------

--
-- Table structure for table `inventaris`
--

CREATE TABLE `inventaris` (
  `id_inventaris` int(255) NOT NULL,
  `nama_inventaris` varchar(255) NOT NULL,
  `deskripsi_inventaris` longtext DEFAULT NULL,
  `status_inventaris` enum('Hanya pinjam','Hanya beli','Dapat pinjam atau beli') DEFAULT 'Hanya pinjam',
  `stok_inventaris` int(5) NOT NULL DEFAULT 0,
  `stok_inventaris_dipinjam` int(5) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventaris`
--

INSERT INTO `inventaris` (`id_inventaris`, `nama_inventaris`, `deskripsi_inventaris`, `status_inventaris`, `stok_inventaris`, `stok_inventaris_dipinjam`) VALUES
(4, 'Hape', 'asek', 'Hanya pinjam', 10, 0),
(5, 'Airpod', 'baru', 'Hanya pinjam', 10, 0),
(6, 'Speaker', 'Something to hear', 'Hanya pinjam', 10, 0),
(7, 'Terminal', 'Share power', 'Hanya pinjam', 15, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `class` enum('X','XI','XII') NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `class`, `email`) VALUES
(0, 'root', 'root', 'XI', 'root'),
(22, 'yeyes', 'yeyes', 'XI', 'yeyes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aksi`
--
ALTER TABLE `aksi`
  ADD PRIMARY KEY (`id_aksi`);

--
-- Indexes for table `inventaris`
--
ALTER TABLE `inventaris`
  ADD PRIMARY KEY (`id_inventaris`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aksi`
--
ALTER TABLE `aksi`
  MODIFY `id_aksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `inventaris`
--
ALTER TABLE `inventaris`
  MODIFY `id_inventaris` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
