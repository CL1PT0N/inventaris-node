## Node.js Invetaris Sarpra

Pre-configuration

1. Clone this repo
2. If there is `package-lock.json`, delete it first
3. Run `npm i` command
4. Create database `inventsarpra`, then import `inventsarpra.sql` (at folder database) to `inventsarpa` database
5. Then import postman template (at postman_template folder) to postman
6. Then run app by `node app`